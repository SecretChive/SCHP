loadTextures({
    "ring":"schp:legion_ring"
});

var utils = implement("fisktag:external/utils");
var model;

function init(renderer) {
    model = utils.createModel(renderer, "schp:legion_ring", "ring");
    renderer.setModel(model);
}

function render(renderer, entity, glProxy, renderType, scopeTimer, recoil, isLeftSide) {
    if (renderType === "EQUIPPED_FIRST_PERSON") {
        glProxy.translate(-0.7, 0.45, 0.0);
        glProxy.rotate(-100, 1, 0, 0);
        glProxy.rotate(-90, 0, 0, 1);
        glProxy.scale(3.0);
    }
    else if (renderType === "ENTITY") {
        glProxy.rotate(90, 1, 0, 0);
        glProxy.rotate(90, 0, 1, 0);
        glProxy.translate(0.0, 0.0, 0.0);
        glProxy.scale(3.0);
        cancelAnimations = true;
    }
    else if (renderType === "INVENTORY") {
        glProxy.rotate(-90, 1, 0, 0);
        glProxy.rotate(-30, 0, 1, 0);
        glProxy.rotate(-30, 0, 0, 1);
        glProxy.translate(0.5, -1.5, 3.0);
        glProxy.scale(12.5);
        cancelAnimations = true;
    }
    else if (renderType === "EQUIPPED") {
        glProxy.rotate(0, 0, 0, 0);
        glProxy.rotate(0.0, 0, 0, 0);
    }
    glProxy.translate(-0.1, 0.181, 0.115);
    glProxy.rotate(-90, 1, 0, 0);
    glProxy.rotate(180, 0, 1, 0);
    glProxy.scale(0.2);
}