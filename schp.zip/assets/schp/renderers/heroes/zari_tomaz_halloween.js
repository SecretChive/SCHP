extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "schp:rip_hunter_layer1",
    "layer2": "schp:rip_hunter_pants"
});

var utils = implement("fiskheroes:external/utils");

function initEffects(renderer) {
    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "schp:water_beam", "rightArm", 0xFFFFFF, [
        { "firstPerson": [-4.5, 3.5, -8.0], "offset": [-0.5, 12.0, 0.0], "size": [2.5, 2.5], "anchor": "rightArm" }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "schp:impact_air"));

    utils.bindCloud(renderer, "fiskheroes:telekinesis", "fiskheroes:telekinesis_monitor");

    var color = 0xFFFFFF;
    var beam = renderer.createResource("BEAM_RENDERER", "schp:water_beam");

    utils.bindBeam(renderer, "fiskheroes:charged_beam", beam, "rightArm", color, [
        { "firstPerson": [-4.5, 3.5, -8.0], "offset": [-0.5, 12.0, 0.0], "size": [2.5, 2.5], "anchor": "rightArm" }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "schp:impact_air"));
}

function initAnimations(renderer) {
    addAnimationWithData(renderer, "zari.TELE", "fiskheroes:aiming_fpcorr", "schp:dyn/telekinesis_timer");
    parent.initAnimations(renderer);
    utils.addHoverAnimation(renderer, "atom.HOVER", "fiskheroes:flight/idle/default_back");
    utils.addFlightAnimation(renderer, "atom.FLIGHT", "fiskheroes:flight/propelled.anim.json", (entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer"));
        data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
        data.load(2, entity.getInterpolatedData("fiskheroes:scale"));
    });
    renderer.removeCustomAnimation("basic.CHARGED_BEAM");
    addAnimationWithData(renderer, "antimonitor.ANTIBLAST", "fiskheroes:aiming", "fiskheroes:beam_charge");
}