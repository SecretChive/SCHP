extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "schp:star_boy_layer1",
    "layer2": "schp:star_boy_layer2"
});

var utils = implement("fiskheroes:external/utils");
var star = implement("schp:external/star_boy_utils");

function initEffects(renderer) {
    star.init(renderer, utils);

    renderer.bindProperty("fiskheroes:gravity_manipulation").color.set(0x00A5FF);
    utils.bindCloud(renderer, "fiskheroes:telekinesis", "fiskheroes:telekinesis_monitor");
    initEquipped(renderer);
}

function initAnimations(renderer) {
    addAnimationWithData(renderer, "starboy.TELE", "fiskheroes:aiming_fpcorr", "schp:dyn/telekinesis_timer");
    utils.addHoverAnimation(renderer, "starboy.HOVER", "fiskheroes:flight/idle/martian_comics");
    addAnimation(renderer, "legion.FLIGHT", "schp:flight/legion_flight.anim.json")
        .setData((entity, data) => {
            data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer") * (1 - entity.getInterpolatedData("fiskheroes:dyn/superhero_landing_timer")));
            data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
        })
        .priority = -10;

    // addAnimation(renderer, "star.tpose", "dhhp:tpose")
    //     .setData((entity, data) => {
    //         data.load(1);
    //     });
    renderer.reprioritizeDefaultAnimation("PUNCH", -9);
    renderer.reprioritizeDefaultAnimation("AIM_BOW", -9);
}

function initEquipped(renderer) {
    renderer.bindProperty("fiskheroes:equipped_item").setItems([{
        "anchor": "rightArm",
        "scale": 0.7,
        "offset": [-0.9, 7.968, -1.55],
        "rotation": [90.0, 0.0, 0.0]
    }]);
}

function render(entity, renderLayer, isFirstPersonArm) {
    star.render(entity, renderLayer, isFirstPersonArm);
}