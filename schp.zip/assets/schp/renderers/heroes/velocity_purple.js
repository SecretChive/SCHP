extend("schp:velocity");
loadTextures({
    "layer1": "schp:velocity/velocity_purple_layer1",
    "layer2": "schp:velocity/velocity_purple_layer2",
    "eyes": "schp:velocity/velocity_purple_eyes",
    "mask": "schp:velocity/velocity_purple_mask.tx.json",
    "lights": "schp:velocity/velocity_purple_mask_lights.tx.json",
    "cape": "schp:velocity/velocity_purple_cape",
    "cape_xor": "schp:velocity/velocity_purple_cape.tx.json"
});
var color = 0x8000FF;

function trail(renderer) {
    speedster.setTrails(["schp:lightning_purple", "schp:lightning_white",  "schp:flicker_comics_purple", "schp:flicker_comics_white"],renderer);
}