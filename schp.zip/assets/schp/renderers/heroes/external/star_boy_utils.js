var starRenderChest; //chestfront
var starRenderChest1; //chestfront
var starRenderChest2; //chestfront
var starRenderChest3; //chestfront
var starRenderChest4; //chestfront
var starRenderChest5; //chestfront
var starRenderChest6; //chestfront
var starRenderChest7; //chestfront
var starRenderChest8; //chestfront

var starRenderArmInb; //arminb
var starRenderArmInb1; //arminb
var starRenderArmInb2; //arminb
var starRenderArmInb3; //arminb
var starRenderArmInb4; //arminb
var starRenderArmInb5; //arminb

var starRenderArmLeft; //armleft
var starRenderArmLeft2; //armleft
var starRenderArmLeft3; //armleft
var starRenderArmLeft4; //armleft
var starRenderArmLeft5; //armleft
var starRenderArmLeft6; //armleft
var starRenderArmLeft7; //armleft
var starRenderArmLeft8; //armleft
var starRenderArmLeft9; //armleft
var starRenderArmLeft10; //armleft




var starRenderArmRight; //armright
var starRenderArmRight1; //armright
var starRenderArmRight2; //armright
var starRenderArmRight3; //armright
var starRenderArmRight4; //armright
var starRenderArmRight5; //armright
var starRenderArmRight6; //armright
var starRenderArmRight7; //armright
var starRenderArmRight8; //armright

//var starRenderChestBack;//chestback
//var starRenderChestBack1;//chestback
//var starRenderChestBack2;//chestback
//var starRenderChestBack3;//chestback
//var starRenderChestBack4;//chestback
//var starRenderChestBack5;//chestback
//var starRenderChestBack6;//chestback
//var starRenderChestBack7;//chestback
//var starRenderChestBack8;//chestback


function init(renderer, utils) {
    var color = 0xFFFFFF;

    //chest front beams
    starRenderChest = utils.createLines(renderer, "schp:stars", color, [ //chestfront
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.8, 0.8] } //chestfront
    ]);
    starRenderChest.anchor.set("body"); //chestfront
    starRenderChest.setOffset(-1.9, 1.9, -2.56).setRotation(0.0, 90.0, 0.0).setScale(16.0); //chestfront

    starRenderChest1 = utils.createLines(renderer, "schp:stars", color, [ //chestfront
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //chestfront
    ]);
    starRenderChest1.anchor.set("body"); //chestfront
    starRenderChest1.setOffset(1.6, 4.0, -2.56).setRotation(0.0, 90.0, 0.0).setScale(16.0); //chestfront

    starRenderChest2 = utils.createLines(renderer, "schp:stars", color, [ //chestfront
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.6, 0.6] } //chestfront
    ]);
    starRenderChest2.anchor.set("body"); //chestfront
    starRenderChest2.setOffset(3.5, 0.8, -2.56).setRotation(0.0, 90.0, 0.0).setScale(16.0); //chestfront

    starRenderChest3 = utils.createLines(renderer, "schp:stars", color, [ //chestfront
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.8, 0.8] } //chestfront
    ]);
    starRenderChest3.anchor.set("body"); //chestfront
    starRenderChest3.setOffset(-2.7, 6.6, -2.56).setRotation(0.0, 90.0, 0.0).setScale(16.0); //chestfront

    starRenderChest4 = utils.createLines(renderer, "schp:stars", color, [ //chestfront
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.6, 0.6] } //chestfront
    ]);
    starRenderChest4.anchor.set("body"); //chestfront
    starRenderChest4.setOffset(2.4, 7.4, -2.56).setRotation(0.0, 90.0, 0.0).setScale(16.0); //chestfront

    starRenderChest5 = utils.createLines(renderer, "schp:stars", color, [ //chestfront
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //chestfront
    ]);
    starRenderChest5.anchor.set("body"); //chestfront
    starRenderChest5.setOffset(-0.4, 8.6, -2.56).setRotation(0.0, 90.0, 0.0).setScale(16.0); //chestfront

    starRenderChest6 = utils.createLines(renderer, "schp:stars", color, [ //chestfront
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.8, 0.8] } //chestfront
    ]);
    starRenderChest6.anchor.set("body"); //chestfront
    starRenderChest6.setOffset(2.8, 10.5, -2.06).setRotation(0.0, 90.0, 0.0).setScale(16.0); //chestfront

    starRenderChest7 = utils.createLines(renderer, "schp:stars", color, [ //chestfront
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //chestfront
    ]);
    starRenderChest7.anchor.set("body"); //chestfront
    starRenderChest7.setOffset(-3.1, 9.7, -2.56).setRotation(0.0, 90.0, 0.0).setScale(16.0); //chestfront

    starRenderChest8 = utils.createLines(renderer, "schp:stars", color, [ //chestfront
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //chestfront
    ]);
    starRenderChest8.anchor.set("body"); //chestfront
    starRenderChest8.setOffset(-1.4, 4.8, -2.56).setRotation(0.0, 90.0, 0.0).setScale(16.0); //chestfront

    //chest back beams

    //Arm inb
    starRenderArmInb = utils.createLines(renderer, "schp:stars", color, [ //arminb
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //arminb
    ]);
    starRenderArmInb.anchor.set("rightArm"); //arminb
    starRenderArmInb.setOffset(-1.1, 3.8, 0.0).setRotation(0.0, 0.0, 0.0).setScale(20.0); //arminb

    starRenderArmInb1 = utils.createLines(renderer, "schp:stars", color, [ //arminb
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //arminb
    ]);
    starRenderArmInb1.anchor.set("rightArm"); //arminb
    starRenderArmInb1.setOffset(-1.1, 1.8, 1.0).setRotation(0.0, 0.0, 0.0).setScale(16.0); //arminb

    starRenderArmInb2 = utils.createLines(renderer, "schp:stars", color, [ //arminb
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //arminb
    ]);
    starRenderArmInb2.anchor.set("rightArm"); //arminb
    starRenderArmInb2.setOffset(-1.1, 1.8, -1.0).setRotation(0.0, 0.0, 0.0).setScale(22.0); //arminb

    starRenderArmInb3 = utils.createLines(renderer, "schp:stars", color, [ //arminb
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //arminb
    ]);
    starRenderArmInb3.anchor.set("leftArm"); //arminb
    starRenderArmInb3.setOffset(1.1, 3.8, 0.0).setRotation(0.0, 0.0, 0.0).setScale(20.0); //arminb

    starRenderArmInb4 = utils.createLines(renderer, "schp:stars", color, [ //arminb
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //arminb
    ]);
    starRenderArmInb4.anchor.set("leftArm"); //arminb
    starRenderArmInb4.setOffset(1.1, 1.8, 1.0).setRotation(0.0, 0.0, 0.0).setScale(16.0); //arminb

    starRenderArmInb5 = utils.createLines(renderer, "schp:stars", color, [ //arminb
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //arminb
    ]);
    starRenderArmInb5.anchor.set("leftArm"); //arminb
    starRenderArmInb5.setOffset(1.1, 1.8, -1.0).setRotation(0.0, 0.0, 0.0).setScale(22.0); //arminb

    //armleft
    starRenderArmLeft = utils.createLines(renderer, "schp:stars", color, [ //armleft
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armleft
    ]);
    starRenderArmLeft.anchor.set("leftArm"); //armleft
    starRenderArmLeft.setOffset(-0.8, 0.44, -2.6).setRotation(0.0, 90.0, 0.0).setScale(28.0); //armleft


    starRenderArmLeft2 = utils.createLines(renderer, "schp:stars", color, [ //armleft
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armleft
    ]);
    starRenderArmLeft2.anchor.set("leftArm"); //armleft
    starRenderArmLeft2.setOffset(-2.11, -0.32, -2.6).setRotation(0.0, 90.0, 0.0).setScale(20.0); //armleft

    starRenderArmLeft3 = utils.createLines(renderer, "schp:stars", color, [ //armleft
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armleft
    ]);
    starRenderArmLeft3.anchor.set("leftArm"); //armleft
    starRenderArmLeft3.setOffset(-2.11, 3.48, -2.6).setRotation(0.0, 90.0, 0.0).setScale(23.0); //armleft

    starRenderArmLeft4 = utils.createLines(renderer, "schp:stars", color, [ //armleft
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armleft
    ]);
    starRenderArmLeft4.anchor.set("leftArm"); //armleft
    starRenderArmLeft4.setOffset(-0.71, 3.1, -2.6).setRotation(0.0, 90.0, 0.0).setScale(14.0); //armleft

    starRenderArmLeft5 = utils.createLines(renderer, "schp:stars", color, [ //armleft
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armleft
    ]);
    starRenderArmLeft5.anchor.set("leftArm"); //armleft
    starRenderArmLeft5.setOffset(-3.1, 3.2, 1.28).setRotation(0.0, 0.0, 0.0).setScale(18.0); //armleft

    starRenderArmLeft6 = utils.createLines(renderer, "schp:stars", color, [ //armleft
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armleft
    ]);
    starRenderArmLeft6.anchor.set("leftArm"); //armleft
    starRenderArmLeft6.setOffset(-3.8, 0.63, -0.58).setRotation(0.0, 0.0, 0.0).setScale(24.0); //armleft

    starRenderArmLeft7 = utils.createLines(renderer, "schp:stars", color, [ //armleft
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armleft
    ]);
    starRenderArmLeft7.anchor.set("leftArm"); //armleft
    starRenderArmLeft7.setOffset(-3.1, 2.2, -0.97).setRotation(0.0, 0.0, 0.0).setScale(14.0); //armleft

    starRenderArmLeft8 = utils.createLines(renderer, "schp:stars", color, [ //armleft
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armleft
    ]);
    starRenderArmLeft8.anchor.set("leftArm"); //armleft
    starRenderArmLeft8.setOffset(-0.54, 0.2, 2.1).setRotation(0.0, 90.0, 0.0).setScale(28.0); //armleft

    starRenderArmLeft9 = utils.createLines(renderer, "schp:stars", color, [ //armleft
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armleft
    ]);
    starRenderArmLeft9.anchor.set("leftArm"); //armleft
    starRenderArmLeft9.setOffset(-1.54, 2.2, 2.6).setRotation(0.0, 90.0, 0.0).setScale(16.0); //armleft

    starRenderArmLeft10 = utils.createLines(renderer, "schp:stars", color, [ //armleft
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armleft
    ]);
    starRenderArmLeft10.anchor.set("leftArm"); //armleft
    starRenderArmLeft10.setOffset(-2.3, -0.2, 2.6).setRotation(0.0, 90.0, 0.0).setScale(20.0); //armleft

    //armright
    starRenderArmRight = utils.createLines(renderer, "schp:stars", color, [ //armright
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armright
    ]);
    starRenderArmRight.anchor.set("rightArm"); //armright
    starRenderArmRight.setOffset(0.31, 3.1, -2.6).setRotation(0.0, 90.0, 0.0).setScale(14.0); //armright

    starRenderArmRight1 = utils.createLines(renderer, "schp:stars", color, [ //armright
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armright
    ]);
    starRenderArmRight1.anchor.set("rightArm"); //armright
    starRenderArmRight1.setOffset(1.81, 1.1, -2.6).setRotation(0.0, 90.0, 0.0).setScale(24.0); //armright

    starRenderArmRight2 = utils.createLines(renderer, "schp:stars", color, [ //armright
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armright
    ]);
    starRenderArmRight2.anchor.set("rightArm"); //armright
    starRenderArmRight2.setOffset(3.1, 2.8, -0.97).setRotation(0.0, 0.0, 0.0).setScale(29.0); //armright

    starRenderArmRight3 = utils.createLines(renderer, "schp:stars", color, [ //armright
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armright
    ]);
    starRenderArmRight3.anchor.set("rightArm"); //armright
    starRenderArmRight3.setOffset(3.7, -0.7, 0.47).setRotation(0.0, 0.0, 0.0).setScale(18.0); //armright

    starRenderArmRight4 = utils.createLines(renderer, "schp:stars", color, [ //armright
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armright
    ]);
    starRenderArmRight4.anchor.set("rightArm"); //armright
    starRenderArmRight4.setOffset(3.7, -0.1, -0.97).setRotation(0.0, 0.0, 0.0).setScale(14.0); //armright

    starRenderArmRight5 = utils.createLines(renderer, "schp:stars", color, [ //armright
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armright
    ]);
    starRenderArmRight5.anchor.set("rightArm"); //armright
    starRenderArmRight5.setOffset(3.1, 3.6, 0.87).setRotation(0.0, 0.0, 0.0).setScale(17.0); //armright

    starRenderArmRight6 = utils.createLines(renderer, "schp:stars", color, [ //armright
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armright
    ]);
    starRenderArmRight6.anchor.set("rightArm"); //armright
    starRenderArmRight6.setOffset(1.51, 0, 2.6).setRotation(0.0, 90.0, 0.0).setScale(24.0); //armright

    starRenderArmRight7 = utils.createLines(renderer, "schp:stars", color, [ //armright
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armright
    ]);
    starRenderArmRight7.anchor.set("rightArm"); //armright
    starRenderArmRight7.setOffset(2.51, 2, 2.6).setRotation(0.0, 90.0, 0.0).setScale(16.0); //armright

    starRenderArmRight8 = utils.createLines(renderer, "schp:stars", color, [ //armright
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 0.0, 0.0], "size": [0.4, 0.4] } //armright
    ]);
    starRenderArmRight8.anchor.set("rightArm"); //armright
    starRenderArmRight8.setOffset(-0.61, 3.5, 2.1).setRotation(0.0, 90.0, 0.0).setScale(20.0); //armright
}

function render(entity, renderLayer, isFirstPersonArm) {

    if (renderLayer == "CHESTPLATE") {
        if (!isFirstPersonArm) {
            starRenderChest.render();
            starRenderChest1.render();
            starRenderChest2.render();
            starRenderChest3.render();
            starRenderChest4.render();
            starRenderChest5.render();
            starRenderChest6.render();
            starRenderChest7.render();
            starRenderChest8.render();


            starRenderArmLeft.render();
            starRenderArmLeft2.render();
            starRenderArmLeft3.render();
            starRenderArmLeft4.render();
            starRenderArmLeft5.render();
            starRenderArmLeft6.render();
            starRenderArmLeft7.render();
            starRenderArmLeft8.render();
            starRenderArmLeft9.render();
            starRenderArmLeft10.render();
        }
        starRenderArmInb.render();
        starRenderArmInb1.render();
        starRenderArmInb2.render();
        starRenderArmInb3.render();
        starRenderArmInb4.render();
        starRenderArmInb5.render();

        starRenderArmRight.render();
        starRenderArmRight1.render();
        starRenderArmRight2.render();
        starRenderArmRight3.render();
        starRenderArmRight4.render();
        starRenderArmRight5.render();
        starRenderArmRight6.render();
        starRenderArmRight7.render();
        starRenderArmRight8.render();

        //        starRenderChestBack.render();
        //        starRenderChestBack1.render();
        //        starRenderChestBack2.render();
        //        starRenderChestBack3.render();
        //        starRenderChestBack4.render();
        //        starRenderChestBack5.render();
        //        starRenderChestBack6.render();
        //       starRenderChestBack7.render();
        //        starRenderChestBack8.render();
    }
}