extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "schp:velocity/velocity_layer1",
    "layer2": "schp:velocity/velocity_layer2",
    "eyes": "schp:velocity/velocity_blue_eyes",
    "mask": "schp:velocity/velocity_mask.tx.json",
    "lights": "schp:velocity/velocity_mask_lights.tx.json",
    "cape": "schp:velocity/velocity_blue_cape",
    "cape_xor": "schp:velocity/velocity_blue_cape.tx.json"
});

var utils = implement("fiskheroes:external/utils");
var capes = implement("fiskheroes:external/capes");
var speedster = implement("schp:external/velocity_utils");

var cape;
var overlay;
var vibration;
var glow;

var color = 0x0059FF;

function trail(renderer) {
    speedster.setTrails(["fiskheroes:velocity_nine", "schp:lightning_white", "schp:flicker_comics_blue", "schp:flicker_comics_white"],renderer);
}

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => renderLayer == "LEGGINGS" ? "layer2" : renderLayer == "HELMET" && entity.getData("fiskheroes:mask_open_timer") > 0 ? "mask" : "layer1");
    renderer.setLights((entity, renderLayer) => renderLayer == "HELMET" && entity.getData("schp:dyn/vibration") ? "eyes" : null);
    trail(renderer);
    initEquipped(renderer);
}

function initEffects(renderer) {
    var physics = renderer.createResource("CAPE_PHYSICS", null);
    physics.maxFlare = 0.4;
    physics.flareDegree = 1.5;
    physics.flareFactor = 1.2;
    physics.flareElasticity = 5;
    cape = capes.createDefault(renderer, 24, "fiskheroes:cape_default.mesh.json", physics);

    glow = renderer.createEffect("fiskheroes:glowerlay");
    glow.includeEffects(cape.effect);
    glow.color.set(0xFFFFFF);

    overlay = renderer.createEffect("fiskheroes:overlay");
    overlay.texture.set(null, "lights");

    vibration = renderer.createEffect("fiskheroes:vibration");
    vibration.includeEffects(cape.effect);

    utils.bindParticles(renderer, "schp:flashbang_glow");

    utils.bindBeam(renderer, "fiskheroes:energy_manipulation", "fiskheroes:energy_discharge", "rightArm", color, [{
                "firstPerson": [-2.5, 0.0, -7.0],
                "offset": [-0.5, 19.0, -12.0],
                "size": [1.5, 1.5]
            }
        ]);

    utils.bindBeam(renderer, "fiskheroes:charged_beam", null, "body", 0xFFFFFF, [{
                "firstPerson": [],
                "offset": [],
                "size": []
            }
        ]);

    speedster.init(renderer);
    initEquipped(renderer);
}

function initAnimations(renderer) {
    utils.addHoverAnimation(renderer, "starboy.HOVER", "fiskheroes:flight/idle/martian_comics");
    parent.initAnimations(renderer);
    addAnimation(renderer, "legion.FLIGHT", "schp:flight/legion_flight.anim.json")
    .setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer") * (1 - entity.getInterpolatedData("fiskheroes:dyn/superhero_landing_timer")));
        data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
    })
    .priority = -10;
    renderer.reprioritizeDefaultAnimation("PUNCH", -9);
    renderer.reprioritizeDefaultAnimation("AIM_BOW", -9);

    addAnimation(renderer, "flash.MASK", "schp:remove_cowl")
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0);
    });
}

function render(entity, renderLayer, isFirstPersonArm) {
    cape.effect.texture.set("cape_xor");
    if (!isFirstPersonArm) {
        if (renderLayer == "CHESTPLATE") {
            cape.effect.length = 24;
            cape.render(entity);
        }
        if (renderLayer == "HELMET") {
            if (entity.getData("fiskheroes:mask_open_timer")) {
                overlay.render();
            }
        }
    }

    if (entity.getData("schp:dyn/vibration")) {
        vibration.render();
    }
    glow.opacity = entity.getData("fiskheroes:beam_shooting");
    glow.render();
}

function initEquipped(renderer) {
    renderer.bindProperty("fiskheroes:equipped_item").setItems([{
                "anchor": "rightArm",
                "scale": 0.7,
                "offset": [-0.9, 7.968, -1.55],
                "rotation": [90.0, 0.0, 0.0]
            }
        ]);
}
