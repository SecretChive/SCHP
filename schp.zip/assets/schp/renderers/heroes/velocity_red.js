extend("schp:velocity");
loadTextures({
    "layer1": "schp:velocity/velocity_red_layer1",
    "layer2": "schp:velocity/velocity_red_layer2",
    "eyes": "schp:velocity/velocity_red_eyes",
    "mask": "schp:velocity/velocity_red_mask.tx.json",
    "lights": "schp:velocity/velocity_red_mask_lights.tx.json",
    "cape": "schp:velocity/velocity_red_cape",
    "cape_xor": "schp:velocity/velocity_red_cape.tx.json"
});
var color = 0xFF0000;

function trail(renderer) {
    speedster.setTrails(["fiskheroes:lightning_red", "schp:lightning_white", "schp:flicker_comics_red", "schp:flicker_comics_white"],renderer);
}