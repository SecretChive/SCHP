function tick(entity, manager) {
    function getEquipmentInSlot(item, slot) {
        var equipment = item.nbt().getTagList("Equipment");
        
        for (var i = 0; i < equipment.tagCount(); ++i) {
            var tag = equipment.getCompoundTag(i);
            var index = tag.getByte("Index");
            
            if (index == slot) {
                return tag.getCompoundTag("Item");
            }
        }
        return null;
    }
    
    var equipment = getEquipmentInSlot(entity.getWornChestplate(), 0);

    if  ((equipment != null && equipment.getCompoundTag("tag").getString("WeaponType") == "schp:legion_ring")) {
        manager.setData(entity, "schp:dyn/legion_ring", true);
    }
    else {
        manager.setData(entity, "schp:dyn/legion_ring", false);
    }
}
