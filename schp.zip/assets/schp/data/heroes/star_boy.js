function init(hero) {
    hero.setName("Star Boy");
    hero.setTier(6);

    hero.setChestplate("Chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fisktag:weapon{WeaponType:schp:legion_ring}", true, item => item.nbt().getString("WeaponType") == 'schp:legion_ring');

    hero.addPowers("schp:gravity_manipulation", "schp:legion_flight_ring");
    hero.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 5.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.2, 1);

    hero.addKeyBind("AIM", "key.gravityManip", 1);
    hero.addKeyBind("GRAVITY_MANIPULATION", "key.gravityManip", 1);
    hero.addKeyBind("TELEKINESIS", "key.telekinesis", 2);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setHasProperty(hasProperty);
    hero.supplyFunction("canAim", canAim);

    hero.addAttributeProfile("RING", ringProfile);
    hero.setAttributeProfile(getProfile);

}

function getEquipmentInSlot(item, slot) {
    var equipment = item.nbt().getTagList("Equipment");
    
    for (var i = 0; i < equipment.tagCount(); ++i) {
        var tag = equipment.getCompoundTag(i);
        var index = tag.getByte("Index");
        
        if (index == slot) {
            return tag.getCompoundTag("Item");
        }
    }
    return null;
}

function ringProfile(profile) {
profile.inheritDefaults();
profile.addAttribute("FALL_RESISTANCE", 1.0, 1);
}

function getProfile(entity) {
    var equipment = getEquipmentInSlot(entity.getWornChestplate(), 0);
    return equipment != null && equipment.getCompoundTag("tag").getString("WeaponType") == "schp:legion_ring" ? "RING" : null;
}

 function isModifierEnabled(entity, modifier) {
    var equipment = getEquipmentInSlot(entity.getWornChestplate(), 0);
     switch (modifier.name()) {
     case "fiskheroes:controlled_flight":
         return equipment != null && equipment.getCompoundTag("tag").getString("WeaponType") == "schp:legion_ring";
     }
     return true;
}

function hasProperty(entity, property) {
    return property == "BREATHE_SPACE";
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:gravity_manip");
}
