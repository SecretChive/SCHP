function init(hero) {
    hero.setName("Zari Tomaz");
    hero.setAliases("zari", "isis");
    hero.setTier(3);

    hero.setHelmet("item.superhero_armor.piece.hair");
    hero.setChestplate("item.superhero_armor.piece.jacket");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("schp:air_totem");
    hero.addAttribute("PUNCH_DAMAGE", 4.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);

    hero.addKeyBind("AIM", "Air Blast", 1);
    hero.addKeyBind("TELEKINESIS", "Air Grab", 2);
    hero.addKeyBind("CHARGED_BEAM", "Wind Gust", 3);
    hero.addKeyBind("TOTEM", "Toggle Totem Powers", 5);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.supplyFunction("canAim", entity => entity.getHeldItem().isEmpty() && entity.getData("schp:dyn/air_totem"));
}

 function isModifierEnabled(entity, modifier) {
     switch (modifier.name()) {
        case "fiskheroes:controlled_flight":
            return entity.getData("schp:dyn/air_totem") && !entity.getData("fiskheroes:beam_charging") && !entity.getData("fiskheroes:telekinesis") && !entity.getData("fiskheroes:aiming");
        case "fiskheroes:repulsor_blast":
            return entity.getData("schp:dyn/air_totem") && !entity.getData("fiskheroes:beam_charging") && !entity.getData("fiskheroes:telekinesis") && !entity.getData("fiskheroes:flying");
        case "fiskheroes:charged_beam":
            return entity.getData("schp:dyn/air_totem") && !entity.getData("fiskheroes:aiming") && !entity.getData("fiskheroes:telekinesis") && !entity.getData("fiskheroes:flying");
        case "fiskheroes:telekinesis":
            return entity.getData("schp:dyn/air_totem") && !entity.getData("fiskheroes:beam_charging") && !entity.getData("fiskheroes:aiming") && !entity.getData("fiskheroes:flying");
        default:
            return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
        case "AIM":
            return entity.getData("schp:dyn/air_totem") && !entity.getData("fiskheroes:beam_charging") && !entity.getData("fiskheroes:telekinesis") && !entity.getData("fiskheroes:flying");
        case "TELEKINESIS":
            return entity.getData("schp:dyn/air_totem") && !entity.getData("fiskheroes:beam_charging") && !entity.getData("fiskheroes:aiming") && !entity.getData("fiskheroes:flying");
        case "CHARGED_BEAM":
            return entity.getData("schp:dyn/air_totem") && !entity.getData("fiskheroes:aiming") && !entity.getData("fiskheroes:telekinesis") && !entity.getData("fiskheroes:flying");
        default:
            return true;
    }
}
