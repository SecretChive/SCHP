var speedster_base = implement("fiskheroes:external/speedster_base");

function init(hero) {
    hero.setName("Velocity");
    hero.setVersion("Secret's Suit");
    hero.setTier(5);

    hero.setHelmet("item.superhero_armor.piece.cowl");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addEquipment("fiskheroes:flash_ring");
    hero.addPrimaryEquipment("fisktag:weapon{WeaponType:schp:legion_ring}", true, item => item.nbt().getString("WeaponType") == 'schp:legion_ring');

    hero.addPowers("fiskheroes:speed_force", "schp:velocity_x", "schp:legion_flight_ring");
    hero.addAttribute("PUNCH_DAMAGE", 4.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.0, 0);
    hero.addAttribute("BASE_SPEED_LEVELS", 4.0, 0);

    hero.addKeyBind("SUPER_SPEED", "key.superSpeed", 1);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotion", 2);
    hero.addKeyBind("CHARGED_BEAM", "Flash Bang", 3);
    hero.addKeyBind("CAPE", "Toggle Cape", 4);
    hero.addKeyBind("VIBRATION", "Toggle Vibration", 5);

    hero.setHasProperty(hasProperty);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setModifierEnabled(isModifierEnabled);

    hero.addAttributeProfile("RING", ringProfile);
    hero.setAttributeProfile(getProfile);

    var speedPunch = speedster_base.createSpeedPunch(hero);

    hero.addSoundEvent("MASK_OPEN", "fiskheroes:mysterio_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:mysterio_mask_close");
    hero.addSoundOverrides("ZOOM", speedster_base.mergeSounds("fiskheroes:speed_force", speedster_base.SOUNDS_ZOOM));

    hero.setTickHandler((entity, manager) => {
        if (entity.getData("fiskheroes:speed_sprinting") != entity.getData("fiskheroes:energy_charging") && entity.getData("fiskheroes:speed") >= 5) {
            manager.setData(entity, "fiskheroes:energy_charging", entity.getData("fiskheroes:speed_sprinting"));
        }
        if (!entity.getData("fiskheroes:speed_sprinting")) {
            manager.setData(entity, "fiskheroes:energy_charge", entity.getData("fiskheroes:energy_charge") - 0.1);
        }
//        if (!getEquipmentInSlot(entity.getWornChestplate(), 0)) {
//           manager.setData(entity, "schp:dyn/legion_ring", 0)
//       }
        speedster_base.tick(entity, manager);
    });
}

function ringProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("FALL_RESISTANCE", 1.0, 1);
    }
    
    function getProfile(entity) {
        var equipment = getEquipmentInSlot(entity.getWornChestplate(), 0);
        return equipment != null && equipment.getCompoundTag("tag").getString("WeaponType") == "schp:legion_ring" ? "RING" : null;
    }

function getEquipmentInSlot(item, slot) {
    var equipment = item.nbt().getTagList("Equipment");
    
    for (var i = 0; i < equipment.tagCount(); ++i) {
        var tag = equipment.getCompoundTag(i);
        var index = tag.getByte("Index");
        
        if (index == slot) {
            return tag.getCompoundTag("Item");
        }
    }
    return null;
}

function isModifierEnabled(entity, modifier) {
    var equipment = getEquipmentInSlot(entity.getWornChestplate(), 0);
     switch (modifier.name()) {
     case "fiskheroes:controlled_flight":
         return equipment != null && equipment.getCompoundTag("tag").getString("WeaponType") == "schp:legion_ring";
     case "fiskheroes:super_speed":
         return !entity.getData("fiskheroes:flying");
     }
     return true;
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
        case "SUPER_SPEED":
            return !entity.getData("fiskheroes:flying");
        case "CHARGED_BEAM":
            return entity.getData('schp:dyn/vibration') && !entity.isSprinting();
        default:
            return true;
    }
}

function canDischargeEnergy(entity) {
    return entity.getHeldItem().isEmpty();
}

function hasProperty(entity, property) {
    return property == "MASK_TOGGLE";
}